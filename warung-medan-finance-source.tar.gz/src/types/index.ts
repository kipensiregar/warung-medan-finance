/**
 * WARUNG MEDAN FINANCE - DATA TYPES & DOMAIN MODELS
 * Warung Medan CT Catering
 */

export type SalesChannel = 'Dine-in' | 'Takeaway' | 'Catering' | 'Bazar' | 'Lainnya';

export type PaymentMethod = 'Tunai' | 'Transfer Bank' | 'QRIS' | 'Campuran';

export type AccountType = 'Kas' | 'Bank' | 'E-Wallet';

export type ExpenseCategory =
  | 'Bahan Baku'
  | 'Gaji Karyawan'
  | 'Sewa Tempat'
  | 'Listrik & Air'
  | 'Gas LPG'
  | 'Transportasi & Bensin'
  | 'Kemasan & Plastik'
  | 'Peralatan Masak'
  | 'Perawatan & Servis'
  | 'Pemasaran & Promosi'
  | 'Administrasi & Bank'
  | 'Pajak & Retribusi'
  | 'Lain-lain';

export type TransactionType =
  | 'PENGELUARAN_OPERASIONAL'
  | 'PEMBELIAN_BAHAN_BAKU'
  | 'PEMBELIAN_ASET'
  | 'PEMBAYARAN_UTANG'
  | 'PENERIMAAN_PIUTANG'
  | 'SETORAN_MODAL'
  | 'PRIVE_PEMILIK'
  | 'TRANSFER_ANTAR_AKUN';

export type UnitType =
  | 'kg'
  | 'gram'
  | 'liter'
  | 'ml'
  | 'butir'
  | 'potong'
  | 'bungkus'
  | 'pack'
  | 'unit'
  | 'ikat';

export type StockMovementType =
  | 'MASUK_PEMBELIAN'
  | 'PEMAKAIAN_MANUAL'
  | 'RUSAK_TERBUANG'
  | 'PENYESUAIAN_OPNAME';

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  accountNumber?: string;
  initialBalance: number;
  currentBalance: number;
  isDefault?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentSplitItem {
  accountId: string;
  accountName: string;
  method: 'Tunai' | 'Transfer Bank' | 'QRIS';
  amount: number;
}

export interface DailySalesSummary {
  id: string;
  date: string; // YYYY-MM-DD
  channel: SalesChannel;
  grossSales: number;
  discount: number;
  refund: number;
  netSales: number; // grossSales - discount - refund
  paymentMethod: PaymentMethod;
  splits: PaymentSplitItem[];
  notes?: string;
  referenceNumber?: string;
  isVoided?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FinancialTransaction {
  id: string;
  date: string; // YYYY-MM-DD
  type: TransactionType;
  category: ExpenseCategory | 'Transfer Antar-Akun' | 'Ekuitas Pemilik' | 'Utang/Piutang';
  amount: number;
  recipientOrSupplier?: string;
  sourceAccountId: string;
  destinationAccountId?: string; // for transfers
  paymentMethod: 'Tunai' | 'Transfer Bank' | 'QRIS';
  notes?: string;
  referenceNumber?: string;
  attachmentUrl?: string;
  isPayableSettlement?: boolean;
  relatedPayableId?: string;
  isReceivableSettlement?: boolean;
  relatedReceivableId?: string;
  isVoided?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Ingredient {
  id: string;
  name: string;
  category: string; // e.g. Bumbu Khas Batak, Daging & Unggas, Ikan Air Tawar, Sayuran, Bahan Pokok
  unit: UnitType;
  initialStock: number;
  currentStock: number;
  minimumStock: number;
  averagePurchasePrice: number; // Weighted average cost per unit
  totalValuation: number; // currentStock * averagePurchasePrice
  defaultSupplier?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  ingredientId: string;
  ingredientName: string;
  date: string; // YYYY-MM-DD
  type: StockMovementType;
  quantity: number; // positive number
  unit: UnitType;
  unitPrice?: number; // for purchase
  totalAmount?: number;
  notes?: string;
  relatedTransactionId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProductMenu {
  id: string;
  name: string;
  category: 'Lauk Utama' | 'Sayur & Pelengkap' | 'Mie & Sarapan' | 'Paket Catering' | 'Minuman';
  sellingPrice: number;
  estimatedHpp?: number;
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payable {
  id: string;
  supplierName: string;
  invoiceDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  status: 'BELUM_LUNAS' | 'SEBAGIAN' | 'LUNAS';
  category: ExpenseCategory;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Receivable {
  id: string;
  customerName: string; // Pelanggan catering / kantor
  invoiceNumber: string;
  orderDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  status: 'BELUM_LUNAS' | 'SEBAGIAN' | 'LUNAS';
  channel: SalesChannel;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OpeningBalanceConfig {
  id: string;
  effectiveDate: string; // YYYY-MM-DD
  cashBalance: number;
  bankBalance: number;
  ewalletBalance: number;
  initialInventoryValue: number;
  initialPayables: number;
  initialReceivables: number;
  ownerEquity: number;
  isConfirmed: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  timestamp: string;
  userEmail?: string;
}

export interface SyncOutboxItem {
  id: string;
  entityType: string;
  entityId: string;
  operation: 'CREATE' | 'UPDATE' | 'DELETE';
  payloadJson: string;
  status: 'PENDING' | 'SYNCED' | 'FAILED';
  retryCount: number;
  lastAttemptAt?: string;
  errorMessage?: string;
  createdAt: string;
}

export interface AppSettings {
  businessName: string;
  ownerName: string;
  address: string;
  phone: string;
  timezone: string;
  pinLockEnabled: boolean;
  pinCode?: string;
  autoSyncEnabled: boolean;
  lastSyncAt?: string;
  lastBackupAt?: string;
}

export interface ProfitLossReport {
  periodLabel: string;
  startDate: string;
  endDate: string;
  grossSales: number;
  discounts: number;
  refunds: number;
  netSales: number;
  // HPP breakdown
  beginningInventory: number;
  purchasesForInventory: number;
  endingInventory: number;
  wasteAndDamagedAdjustments: number;
  costOfGoodsSold: number; // HPP
  grossProfit: number; // netSales - costOfGoodsSold
  grossMarginPct: number;
  // Operating Expenses
  operatingExpenses: Record<ExpenseCategory, number>;
  totalOperatingExpenses: number;
  // Operating Profit
  operatingProfit: number;
  // Non-operating / others
  otherIncome: number;
  otherExpenses: number;
  netProfit: number; // Laba Bersih
  netMarginPct: number;
}

export interface CashFlowReport {
  periodLabel: string;
  startDate: string;
  endDate: string;
  startingCash: number;
  cashInflowFromSales: number;
  cashInflowFromReceivables: number;
  cashInflowFromCapital: number;
  totalCashInflow: number;
  cashOutflowOperating: number;
  cashOutflowInventoryPurchases: number;
  cashOutflowDebtPayments: number;
  cashOutflowAssetPurchases: number;
  cashOutflowPrive: number;
  totalCashOutflow: number;
  netCashFlow: number;
  endingCash: number;
}
