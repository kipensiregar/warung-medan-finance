/**
 * WARUNG MEDAN FINANCE - ACCOUNTING ENGINE SERVICE
 * Warung Medan CT Catering
 *
 * Implements strict Indonesian GAAP (SAK EMKM) standards for small business:
 * - Penjualan Bersih = Penjualan Kotor - Diskon - Refund
 * - HPP = Persediaan Awal + Pembelian Bersih Bahan - Persediaan Akhir + Penyesuaian Rusak
 * - Laba Kotor = Penjualan Bersih - HPP
 * - Laba Bersih = Laba Kotor - Total Beban Operasional
 * - Cashflow = Saldo Awal + Arus Masuk Riil - Arus Keluar Riil = Saldo Akhir
 * - Inter-account transfers and Owner Equity/Prive strictly quarantined from operating P&L
 */

import { db } from '../database/db';
import type { ProfitLossReport, CashFlowReport, ExpenseCategory } from '../types';

export const accountingService = {
  /**
   * Hitung Laporan Laba Rugi untuk rentang tanggal tertentu
   */
  async calculateProfitLoss(
    startDate: string,
    endDate: string,
    periodLabel: string
  ): Promise<ProfitLossReport> {
    // 1. Ambil Penjualan Harian
    const salesList = await db.dailySales
      .filter((s) => !s.isVoided && s.date >= startDate && s.date <= endDate)
      .toArray();

    const grossSales = salesList.reduce((sum, s) => sum + s.grossSales, 0);
    const discounts = salesList.reduce((sum, s) => sum + s.discount, 0);
    const refunds = salesList.reduce((sum, s) => sum + s.refund, 0);
    const netSales = Math.round(grossSales - discounts - refunds);

    // 2. Ambil Persediaan & HPP
    // Ambil semua pergerakan bahan dalam periode ini
    const movements = await db.stockMovements
      .filter((m) => m.date >= startDate && m.date <= endDate)
      .toArray();

    let purchasesForInventory = 0;
    let wasteAndDamagedAdjustments = 0;
    let manualUsageCost = 0;

    for (const mov of movements) {
      if (mov.type === 'MASUK_PEMBELIAN') {
        purchasesForInventory += mov.totalAmount || 0;
      } else if (mov.type === 'RUSAK_TERBUANG') {
        wasteAndDamagedAdjustments += mov.totalAmount || 0;
      } else if (mov.type === 'PEMAKAIAN_MANUAL') {
        manualUsageCost += mov.totalAmount || 0;
      }
    }

    // Ambil bahan terkini untuk nilai persediaan
    const ingredients = await db.ingredients.filter((i) => i.isActive).toArray();
    const endingInventory = ingredients.reduce((sum, i) => sum + i.totalValuation, 0);

    // Estimasi persediaan awal: Ending - Purchases + ManualUsage + Waste
    const beginningInventory = Math.max(
      0,
      Math.round(endingInventory - purchasesForInventory + manualUsageCost + wasteAndDamagedAdjustments)
    );

    // Formula HPP:
    // HPP = Persediaan Awal + Pembelian - Persediaan Akhir + Kerusakan Bahan
    // Secara akuntansi ekuivalen dengan (manualUsageCost + wasteAndDamagedAdjustments)
    const costOfGoodsSold = Math.max(
      0,
      Math.round(manualUsageCost + wasteAndDamagedAdjustments)
    );

    const grossProfit = Math.round(netSales - costOfGoodsSold);
    const grossMarginPct = netSales > 0 ? Number(((grossProfit / netSales) * 100).toFixed(1)) : 0;

    // 3. Ambil Beban Operasional
    const transactions = await db.transactions
      .filter((t) => !t.isVoided && t.date >= startDate && t.date <= endDate)
      .toArray();

    const initialOperatingMap: Record<ExpenseCategory, number> = {
      'Bahan Baku': 0, // dihitung di HPP
      'Gaji Karyawan': 0,
      'Sewa Tempat': 0,
      'Listrik & Air': 0,
      'Gas LPG': 0,
      'Transportasi & Bensin': 0,
      'Kemasan & Plastik': 0,
      'Peralatan Masak': 0,
      'Perawatan & Servis': 0,
      'Pemasaran & Promosi': 0,
      'Administrasi & Bank': 0,
      'Pajak & Retribusi': 0,
      'Lain-lain': 0
    };

    let totalOperatingExpenses = 0;

    for (const tx of transactions) {
      if (tx.type === 'PENGELUARAN_OPERASIONAL') {
        const cat = tx.category as ExpenseCategory;
        if (initialOperatingMap[cat] !== undefined) {
          initialOperatingMap[cat] += tx.amount;
        } else {
          initialOperatingMap['Lain-lain'] += tx.amount;
        }
        totalOperatingExpenses += tx.amount;
      }
    }

    const operatingProfit = Math.round(grossProfit - totalOperatingExpenses);
    const otherIncome = 0;
    const otherExpenses = 0;
    const netProfit = Math.round(operatingProfit + otherIncome - otherExpenses);
    const netMarginPct = netSales > 0 ? Number(((netProfit / netSales) * 100).toFixed(1)) : 0;

    return {
      periodLabel,
      startDate,
      endDate,
      grossSales,
      discounts,
      refunds,
      netSales,
      beginningInventory,
      purchasesForInventory,
      endingInventory,
      wasteAndDamagedAdjustments,
      costOfGoodsSold,
      grossProfit,
      grossMarginPct,
      operatingExpenses: initialOperatingMap,
      totalOperatingExpenses,
      operatingProfit,
      otherIncome,
      otherExpenses,
      netProfit,
      netMarginPct
    };
  },

  /**
   * Hitung Laporan Arus Kas (Cash Flow)
   */
  async calculateCashFlow(
    startDate: string,
    endDate: string,
    periodLabel: string
  ): Promise<CashFlowReport> {
    const accounts = await db.accounts.toArray();
    const startingCash = accounts.reduce((sum, a) => sum + a.initialBalance, 0);

    // 1. Arus Kas Masuk
    const salesList = await db.dailySales
      .filter((s) => !s.isVoided && s.date >= startDate && s.date <= endDate)
      .toArray();

    const cashInflowFromSales = salesList.reduce((sum, s) => sum + s.netSales, 0);

    const transactions = await db.transactions
      .filter((t) => !t.isVoided && t.date >= startDate && t.date <= endDate)
      .toArray();

    let cashInflowFromReceivables = 0;
    let cashInflowFromCapital = 0;

    let cashOutflowOperating = 0;
    let cashOutflowInventoryPurchases = 0;
    let cashOutflowDebtPayments = 0;
    let cashOutflowAssetPurchases = 0;
    let cashOutflowPrive = 0;

    for (const tx of transactions) {
      if (tx.type === 'PENERIMAAN_PIUTANG') {
        cashInflowFromReceivables += tx.amount;
      } else if (tx.type === 'SETORAN_MODAL') {
        cashInflowFromCapital += tx.amount;
      } else if (tx.type === 'PENGELUARAN_OPERASIONAL') {
        cashOutflowOperating += tx.amount;
      } else if (tx.type === 'PEMBELIAN_BAHAN_BAKU') {
        cashOutflowInventoryPurchases += tx.amount;
      } else if (tx.type === 'PEMBAYARAN_UTANG') {
        cashOutflowDebtPayments += tx.amount;
      } else if (tx.type === 'PEMBELIAN_ASET') {
        cashOutflowAssetPurchases += tx.amount;
      } else if (tx.type === 'PRIVE_PEMILIK') {
        cashOutflowPrive += tx.amount;
      }
      // Note: TRANSFER_ANTAR_AKUN diabaikan dari total arus kas bersih karena kas keluar = kas masuk
    }

    const totalCashInflow = cashInflowFromSales + cashInflowFromReceivables + cashInflowFromCapital;
    const totalCashOutflow =
      cashOutflowOperating +
      cashOutflowInventoryPurchases +
      cashOutflowDebtPayments +
      cashOutflowAssetPurchases +
      cashOutflowPrive;

    const netCashFlow = totalCashInflow - totalCashOutflow;
    const endingCash = accounts.reduce((sum, a) => sum + a.currentBalance, 0);

    return {
      periodLabel,
      startDate,
      endDate,
      startingCash,
      cashInflowFromSales,
      cashInflowFromReceivables,
      cashInflowFromCapital,
      totalCashInflow,
      cashOutflowOperating,
      cashOutflowInventoryPurchases,
      cashOutflowDebtPayments,
      cashOutflowAssetPurchases,
      cashOutflowPrive,
      totalCashOutflow,
      netCashFlow,
      endingCash
    };
  }
};
