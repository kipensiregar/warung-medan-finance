/**
 * Sync & Backup Repository - Warung Medan Finance
 * Offline-first Outbox queue, JSON backup/restore, audit trail
 */

import { db } from '../db';
import type { AppSettings, OpeningBalanceConfig, AuditLog } from '../../types';

export const syncRepository = {
  async getSettings(): Promise<AppSettings> {
    const list = await db.settings.toArray();
    if (list.length > 0) return list[0];
    return {
      businessName: 'Warung Medan CT Catering',
      ownerName: 'Pemilik Usaha CT',
      address: 'Jl. Danau Toba Raya No. 18, Medan',
      phone: '0812-3456-7890',
      timezone: 'Asia/Jakarta',
      pinLockEnabled: false,
      autoSyncEnabled: true,
      lastSyncAt: new Date().toISOString()
    };
  },

  async updateSettings(settings: Partial<AppSettings>): Promise<void> {
    const current = await this.getSettings();
    const updated = { ...current, ...settings, id: 'app_settings' };
    await db.settings.put(updated);
  },

  async getOpeningBalance(): Promise<OpeningBalanceConfig | undefined> {
    const list = await db.openingBalances.toArray();
    return list[0];
  },

  async saveOpeningBalance(config: OpeningBalanceConfig): Promise<void> {
    await db.transaction('rw', [db.openingBalances, db.accounts, db.auditLogs], async () => {
      await db.openingBalances.put(config);

      // Sinkronkan ke saldo awal akun jika dikonfirmasi
      const accounts = await db.accounts.toArray();
      for (const acc of accounts) {
        if (acc.type === 'Kas') {
          await db.accounts.update(acc.id, {
            initialBalance: config.cashBalance,
            currentBalance: config.cashBalance
          });
        } else if (acc.type === 'Bank') {
          await db.accounts.update(acc.id, {
            initialBalance: config.bankBalance,
            currentBalance: config.bankBalance
          });
        } else if (acc.type === 'E-Wallet') {
          await db.accounts.update(acc.id, {
            initialBalance: config.ewalletBalance,
            currentBalance: config.ewalletBalance
          });
        }
      }

      await db.auditLogs.add({
        id: `audit_${Date.now()}`,
        action: 'UPDATE_OPENING_BALANCE',
        entityType: 'OPENING_BALANCE',
        entityId: config.id,
        details: `Saldo awal pembukuan dikonfirmasi: Kas Rp${config.cashBalance.toLocaleString('id-ID')}, Bank Rp${config.bankBalance.toLocaleString('id-ID')}`,
        timestamp: new Date().toISOString()
      });
    });
  },

  async getAuditLogs(limit = 100): Promise<AuditLog[]> {
    return await db.auditLogs.orderBy('timestamp').reverse().limit(limit).toArray();
  },

  async getPendingSyncCount(): Promise<number> {
    return await db.syncOutbox.filter((item) => item.status === 'PENDING').count();
  },

  /**
   * Export all data tables into a validated JSON backup bundle
   */
  async exportFullBackupJson(): Promise<string> {
    const backupData = {
      app: 'Warung Medan Finance',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      businessName: 'Warung Medan CT Catering',
      data: {
        accounts: await db.accounts.toArray(),
        dailySales: await db.dailySales.toArray(),
        transactions: await db.transactions.toArray(),
        ingredients: await db.ingredients.toArray(),
        stockMovements: await db.stockMovements.toArray(),
        products: await db.products.toArray(),
        payables: await db.payables.toArray(),
        receivables: await db.receivables.toArray(),
        openingBalances: await db.openingBalances.toArray(),
        auditLogs: await db.auditLogs.toArray(),
        settings: await db.settings.toArray()
      }
    };

    return JSON.stringify(backupData, null, 2);
  },

  /**
   * Restore database from backup JSON bundle with full safety transaction
   */
  async restoreBackupJson(jsonString: string): Promise<{ success: boolean; message: string }> {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.app || !parsed.data) {
        throw new Error('Format file backup tidak valid untuk Warung Medan Finance');
      }

      const { data } = parsed;
      await db.transaction(
        'rw',
        [
          db.accounts,
          db.dailySales,
          db.transactions,
          db.ingredients,
          db.stockMovements,
          db.products,
          db.payables,
          db.receivables,
          db.openingBalances,
          db.auditLogs,
          db.settings
        ],
        async () => {
          if (data.accounts?.length) {
            await db.accounts.clear();
            await db.accounts.bulkAdd(data.accounts);
          }
          if (data.dailySales?.length) {
            await db.dailySales.clear();
            await db.dailySales.bulkAdd(data.dailySales);
          }
          if (data.transactions?.length) {
            await db.transactions.clear();
            await db.transactions.bulkAdd(data.transactions);
          }
          if (data.ingredients?.length) {
            await db.ingredients.clear();
            await db.ingredients.bulkAdd(data.ingredients);
          }
          if (data.stockMovements?.length) {
            await db.stockMovements.clear();
            await db.stockMovements.bulkAdd(data.stockMovements);
          }
          if (data.products?.length) {
            await db.products.clear();
            await db.products.bulkAdd(data.products);
          }
          if (data.payables?.length) {
            await db.payables.clear();
            await db.payables.bulkAdd(data.payables);
          }
          if (data.receivables?.length) {
            await db.receivables.clear();
            await db.receivables.bulkAdd(data.receivables);
          }
          if (data.openingBalances?.length) {
            await db.openingBalances.clear();
            await db.openingBalances.bulkAdd(data.openingBalances);
          }
          if (data.auditLogs?.length) {
            await db.auditLogs.clear();
            await db.auditLogs.bulkAdd(data.auditLogs);
          }
          if (data.settings?.length) {
            await db.settings.clear();
            await db.settings.bulkAdd(data.settings);
          }

          await db.auditLogs.add({
            id: `audit_restore_${Date.now()}`,
            action: 'RESTORE_BACKUP',
            entityType: 'DATABASE',
            entityId: 'SYSTEM',
            details: `Pemulihan data cadangan berhasil dari ekspor tanggal ${parsed.exportedAt || 'tidak diketahui'}`,
            timestamp: new Date().toISOString()
          });
        }
      );

      return {
        success: true,
        message: 'Pemulihan data cadangan berhasil! Semua catatan keuangan telah diperbarui.'
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Gagal memulihkan cadangan: ${err.message || 'File rusak atau tidak valid'}`
      };
    }
  }
};
