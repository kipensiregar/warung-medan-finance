/**
 * WARUNG MEDAN FINANCE - DEXIE OFFLINE-FIRST DATABASE
 * Warung Medan CT Catering
 */

import Dexie, { type Table } from 'dexie';
import type {
  Account,
  DailySalesSummary,
  FinancialTransaction,
  Ingredient,
  StockMovement,
  ProductMenu,
  Payable,
  Receivable,
  OpeningBalanceConfig,
  AuditLog,
  SyncOutboxItem,
  AppSettings
} from '../types';

export class WarungFinanceDB extends Dexie {
  accounts!: Table<Account, string>;
  dailySales!: Table<DailySalesSummary, string>;
  transactions!: Table<FinancialTransaction, string>;
  ingredients!: Table<Ingredient, string>;
  stockMovements!: Table<StockMovement, string>;
  products!: Table<ProductMenu, string>;
  payables!: Table<Payable, string>;
  receivables!: Table<Receivable, string>;
  openingBalances!: Table<OpeningBalanceConfig, string>;
  auditLogs!: Table<AuditLog, string>;
  syncOutbox!: Table<SyncOutboxItem, string>;
  settings!: Table<AppSettings & { id: string }, string>;

  constructor() {
    super('WarungMedanFinanceDB');
    this.version(1).stores({
      accounts: 'id, name, type',
      dailySales: 'id, date, channel, paymentMethod, isVoided',
      transactions: 'id, date, type, category, sourceAccountId, isVoided',
      ingredients: 'id, name, category, isActive',
      stockMovements: 'id, ingredientId, date, type',
      products: 'id, name, category, isActive',
      payables: 'id, supplierName, dueDate, status',
      receivables: 'id, customerName, dueDate, status',
      openingBalances: 'id, effectiveDate',
      auditLogs: 'id, timestamp, action, entityType',
      syncOutbox: 'id, entityType, status, createdAt',
      settings: 'id'
    });
  }
}

export const db = new WarungFinanceDB();

/**
 * Initial Default Seed Data for Warung Medan CT Catering
 */
export async function seedInitialDataIfEmpty(): Promise<void> {
  const accountCount = await db.accounts.count();
  if (accountCount > 0) return;

  const now = new Date().toISOString();
  const today = now.slice(0, 10);

  // 1. Initial Accounts
  const initialAccounts: Account[] = [
    {
      id: 'acc_kas_utama',
      name: 'Kas Fisik Warung (Laci)',
      type: 'Kas',
      accountNumber: 'KAS-WARUNG-01',
      initialBalance: 2500000,
      currentBalance: 2500000,
      isDefault: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'acc_bank_bca',
      name: 'BCA Rekening Operasional (CT Catering)',
      type: 'Bank',
      accountNumber: '8220194829',
      initialBalance: 15000000,
      currentBalance: 15000000,
      isDefault: false,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'acc_qris_mandiri',
      name: 'QRIS & E-Wallet Warung',
      type: 'E-Wallet',
      accountNumber: 'QRIS-MEDAN-88',
      initialBalance: 1200000,
      currentBalance: 1200000,
      isDefault: false,
      createdAt: now,
      updatedAt: now
    }
  ];
  await db.accounts.bulkAdd(initialAccounts);

  // 2. Ingredients Master (Spesialis Bumbu & Kuliner Medan)
  const initialIngredients: Ingredient[] = [
    {
      id: 'ing_andaliman',
      name: 'Andaliman Segar Khas Toba',
      category: 'Bumbu Khas Batak',
      unit: 'kg',
      initialStock: 12,
      currentStock: 12,
      minimumStock: 3,
      averagePurchasePrice: 85000,
      totalValuation: 12 * 85000,
      defaultSupplier: 'Inang Pasar Sambu Medan',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_beras_ramos',
      name: 'Beras Ramos Super',
      category: 'Bahan Pokok',
      unit: 'kg',
      initialStock: 250,
      currentStock: 250,
      minimumStock: 50,
      averagePurchasePrice: 15000,
      totalValuation: 250 * 15000,
      defaultSupplier: 'Toko Beras Sinar Jaya',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_ayam_kampung',
      name: 'Ayam Kampung Segar (Napinadar)',
      category: 'Daging & Unggas',
      unit: 'potong',
      initialStock: 40,
      currentStock: 40,
      minimumStock: 10,
      averagePurchasePrice: 65000,
      totalValuation: 40 * 65000,
      defaultSupplier: 'Agen Ayam Berastagi',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_ikan_mas',
      name: 'Ikan Mas Segar Hidup (Arsik)',
      category: 'Ikan Air Tawar',
      unit: 'kg',
      initialStock: 35,
      currentStock: 35,
      minimumStock: 8,
      averagePurchasePrice: 42000,
      totalValuation: 35 * 42000,
      defaultSupplier: 'Petani Ikan Toba',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_ikan_nila',
      name: 'Ikan Nila Segar (Tombur/Goreng)',
      category: 'Ikan Air Tawar',
      unit: 'kg',
      initialStock: 30,
      currentStock: 30,
      minimumStock: 10,
      averagePurchasePrice: 36000,
      totalValuation: 30 * 36000,
      defaultSupplier: 'Petani Ikan Toba',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_santan_kental',
      name: 'Santan Kelapa Murni',
      category: 'Bahan Pokok',
      unit: 'liter',
      initialStock: 25,
      currentStock: 25,
      minimumStock: 5,
      averagePurchasePrice: 22000,
      totalValuation: 25 * 22000,
      defaultSupplier: 'Giling Kelapa Berkah',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_cabai_merah',
      name: 'Cabai Merah Keriting Medan',
      category: 'Bumbu & Rempah',
      unit: 'kg',
      initialStock: 20,
      currentStock: 20,
      minimumStock: 5,
      averagePurchasePrice: 45000,
      totalValuation: 20 * 45000,
      defaultSupplier: 'Pasar Induk Sayur',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_minyak_goreng',
      name: 'Minyak Goreng Jerigen Kemasan',
      category: 'Bahan Pokok',
      unit: 'liter',
      initialStock: 60,
      currentStock: 60,
      minimumStock: 15,
      averagePurchasePrice: 17500,
      totalValuation: 60 * 17500,
      defaultSupplier: 'Distributor Sembako Medan',
      isActive: true,
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'ing_kotak_catering',
      name: 'Kotak Nasi Catering Eksklusif CT',
      category: 'Kemasan & Wadah',
      unit: 'pack',
      initialStock: 15,
      currentStock: 15,
      minimumStock: 5,
      averagePurchasePrice: 85000,
      totalValuation: 15 * 85000,
      defaultSupplier: 'Percetakan Kemasan Nusantara',
      isActive: true,
      createdAt: now,
      updatedAt: now
    }
  ];
  await db.ingredients.bulkAdd(initialIngredients);

  // 3. Master Products (Menu Masakan Medan CT Catering)
  const initialProducts: ProductMenu[] = [
    {
      id: 'prd_napinadar',
      name: 'Paket Ayam Napinadar Khas Batak',
      category: 'Lauk Utama',
      sellingPrice: 45000,
      estimatedHpp: 24000,
      isActive: true,
      notes: 'Disajikan dengan sambal goti andaliman & daun ubi tumbuk',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_naniura',
      name: 'Naniura Ikan Mas (Sashimi Khas Batak)',
      category: 'Lauk Utama',
      sellingPrice: 50000,
      estimatedHpp: 26000,
      isActive: true,
      notes: 'Ikan segar dimatangkan asam jungga & bumbu andaliman',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_arsik',
      name: 'Arsik Ikan Mas Andaliman',
      category: 'Lauk Utama',
      sellingPrice: 42000,
      estimatedHpp: 22000,
      isActive: true,
      notes: 'Kaya rempah lokio, asam gelugur & andaliman',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_nila_tombur',
      name: 'Nila Bakar/Goreng Sambal Tombur',
      category: 'Lauk Utama',
      sellingPrice: 38000,
      estimatedHpp: 19000,
      isActive: true,
      notes: 'Sambal tombur andaliman kecombrang',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_mie_sop',
      name: 'Mie Sop Medan Kaldu Ayam Spesial',
      category: 'Mie & Sarapan',
      sellingPrice: 25000,
      estimatedHpp: 11000,
      isActive: true,
      notes: 'Kuah rempah wangi kapulaga kayu manis, kerupuk merah',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_mie_gomak_kuah',
      name: 'Mie Gomak Kuah Lontong Andaliman',
      category: 'Mie & Sarapan',
      sellingPrice: 22000,
      estimatedHpp: 9500,
      isActive: true,
      notes: 'Spaghetti batak dengan kuah santan bumbu andaliman gurih pedas',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_mie_gomak_goreng',
      name: 'Mie Gomak Goreng Sambal Kacang',
      category: 'Mie & Sarapan',
      sellingPrice: 22000,
      estimatedHpp: 9000,
      isActive: true,
      notes: 'Mie gomak kenyal digoreng bumbu andaliman + taburan bawang goreng',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_lontong_medan',
      name: 'Lontong Sayur Medan Komplit',
      category: 'Mie & Sarapan',
      sellingPrice: 28000,
      estimatedHpp: 12500,
      isActive: true,
      notes: 'Sayur tauco, rendang telur, sambal teri kacang, kerupuk udang',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_catering_prasmanan',
      name: 'Paket Catering Prasmanan Adat/Pesta (Per Porsi)',
      category: 'Paket Catering',
      sellingPrice: 65000,
      estimatedHpp: 32000,
      isActive: true,
      notes: 'Menu lengkap lauk utama, sop, sayur, sambal andaliman & buah',
      createdAt: now,
      updatedAt: now
    },
    {
      id: 'prd_nasi_kotak_ct',
      name: 'Nasi Kotak Catering CT Premium',
      category: 'Paket Catering',
      sellingPrice: 38000,
      estimatedHpp: 18000,
      isActive: true,
      notes: 'Nasi pulen, lauk pilihan khas medan, lalapan & air mineral',
      createdAt: now,
      updatedAt: now
    }
  ];
  await db.products.bulkAdd(initialProducts);

  // 4. Opening Balance Record
  const initialInventoryVal = initialIngredients.reduce((sum, item) => sum + item.totalValuation, 0);
  const openingConfig: OpeningBalanceConfig = {
    id: 'opening_cfg_default',
    effectiveDate: today,
    cashBalance: 2500000,
    bankBalance: 15000000,
    ewalletBalance: 1200000,
    initialInventoryValue: initialInventoryVal,
    initialPayables: 3500000,
    initialReceivables: 4800000,
    ownerEquity: 2500000 + 15000000 + 1200000 + initialInventoryVal + 4800000 - 3500000,
    isConfirmed: true,
    notes: 'Saldo pembukuan awal Warung Medan CT Catering',
    createdAt: now,
    updatedAt: now
  };
  await db.openingBalances.add(openingConfig);

  // 5. Initial Payables (Utang ke Supplier Bahan)
  const initialPayables: Payable[] = [
    {
      id: 'pay_001',
      supplierName: 'Agen Ayam Berastagi',
      invoiceDate: today,
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
      totalAmount: 3500000,
      paidAmount: 1000000,
      remainingAmount: 2500000,
      status: 'SEBAGIAN',
      category: 'Bahan Baku',
      notes: 'Pasokan 60 ekor ayam kampung untuk pesanan catering',
      createdAt: now,
      updatedAt: now
    }
  ];
  await db.payables.bulkAdd(initialPayables);

  // 6. Initial Receivables (Piutang dari Pelanggan Catering)
  const initialReceivables: Receivable[] = [
    {
      id: 'rec_001',
      customerName: 'Keluarga Bpk. S. Panjaitan (Arisan Keluarga)',
      invoiceNumber: 'INV/CT-CAT/2026/001',
      orderDate: today,
      dueDate: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10),
      totalAmount: 4800000,
      paidAmount: 2000000,
      remainingAmount: 2800000,
      status: 'SEBAGIAN',
      channel: 'Catering',
      notes: 'DP 2jt diterima, pelunasan saat hantaran prasmanan',
      createdAt: now,
      updatedAt: now
    }
  ];
  await db.receivables.bulkAdd(initialReceivables);

  // 7. Settings
  const appSettings: AppSettings & { id: string } = {
    id: 'app_settings',
    businessName: 'Warung Medan CT Catering',
    ownerName: 'Pemilik Usaha CT',
    address: 'Jl. Danau Toba Raya No. 18, Medan',
    phone: '0812-3456-7890',
    timezone: 'Asia/Jakarta',
    pinLockEnabled: false,
    autoSyncEnabled: true,
    lastSyncAt: now,
    lastBackupAt: now
  };
  await db.settings.add(appSettings);

  // 8. Audit Log
  await db.auditLogs.add({
    id: 'audit_init',
    action: 'INIT_DATABASE',
    entityType: 'SYSTEM',
    entityId: 'SYSTEM',
    details: 'Database lokal diinisialisasi dengan master data Warung Medan CT Catering',
    timestamp: now
  });
}
