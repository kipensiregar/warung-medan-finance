/**
 * REPORTS VIEW - Laporan Laba Rugi, Arus Kas, Utang Piutang & Histori
 * Warung Medan CT Catering
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PeriodFilter } from '../../components/common/PeriodFilter';
import { accountingService } from '../../services/accountingService';
import { debtRepository } from '../../database/repositories/debtRepository';
import { transactionRepository } from '../../database/repositories/transactionRepository';
import type { ProfitLossReport, CashFlowReport, Payable, Receivable, ExpenseCategory } from '../../types';
import {
  formatRupiah,
  formatIndonesianDate,
  generateCsv,
  downloadFile,
  printFinancialReport
} from '../../utils/formatters';
import {
  FileText,
  Printer,
  Download,
  DollarSign,
  Layers,
  Scale,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Plus
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { dateRange, accounts, refreshData, showToast } = useApp();

  const [activeReportTab, setActiveReportTab] = useState<'PNL' | 'CASHFLOW' | 'DEBTS' | 'HISTORY'>('PNL');
  const [pnlReport, setPnlReport] = useState<ProfitLossReport | null>(null);
  const [cashFlowReport, setCashFlowReport] = useState<CashFlowReport | null>(null);
  const [payables, setPayables] = useState<Payable[]>([]);
  const [receivables, setReceivables] = useState<Receivable[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Settlement modal for payables or receivables
  const [settlementTarget, setSettlementTarget] = useState<{
    type: 'PAYABLE' | 'RECEIVABLE';
    item: Payable | Receivable;
  } | null>(null);
  const [settleAmountInput, setSettleAmountInput] = useState('');
  const [settleAccountId, setSettleAccountId] = useState(accounts[0]?.id || '');

  // Add new payable / receivable modal
  const [isAddPayableOpen, setIsAddPayableOpen] = useState(false);
  const [isAddReceivableOpen, setIsAddReceivableOpen] = useState(false);
  const [newSupplier, setNewSupplier] = useState('');
  const [newCustomer, setNewCustomer] = useState('');
  const [newAmountInput, setNewAmountInput] = useState('');
  const [newDueDate, setNewDueDate] = useState(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
  const [newNotes, setNewNotes] = useState('');

  const loadReports = async () => {
    try {
      setIsLoading(true);
      const [pnl, cf, pays, recs] = await Promise.all([
        accountingService.calculateProfitLoss(dateRange.startDate, dateRange.endDate, dateRange.label),
        accountingService.calculateCashFlow(dateRange.startDate, dateRange.endDate, dateRange.label),
        debtRepository.getAllPayables(),
        debtRepository.getAllReceivables()
      ]);
      setPnlReport(pnl);
      setCashFlowReport(cf);
      setPayables(pays);
      setReceivables(recs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, [dateRange]);

  // Handle debt settlement (cicilan / lunas)
  const handleSettleDebt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settlementTarget) return;

    const amount = Math.max(0, parseInt(settleAmountInput.replace(/\D/g, ''), 10) || 0);
    if (amount <= 0) {
      showToast('Nominal pembayaran harus lebih dari 0', 'error');
      return;
    }

    try {
      const today = new Date().toISOString().slice(0, 10);
      const isPayable = settlementTarget.type === 'PAYABLE';
      const target = settlementTarget.item;

      await transactionRepository.createTransaction({
        date: today,
        type: isPayable ? 'PEMBAYARAN_UTANG' : 'PENERIMAAN_PIUTANG',
        category: 'Utang/Piutang',
        amount,
        sourceAccountId: settleAccountId,
        recipientOrSupplier: isPayable ? (target as Payable).supplierName : (target as Receivable).customerName,
        paymentMethod: 'Transfer Bank',
        notes: `Pelunasan/cicilan tagihan: ${isPayable ? (target as Payable).supplierName : (target as Receivable).customerName}`,
        relatedPayableId: isPayable ? target.id : undefined,
        relatedReceivableId: !isPayable ? target.id : undefined
      });

      showToast('Pembayaran berhasil dicatat dan saldo utang diperbarui!', 'success');
      setSettlementTarget(null);
      setSettleAmountInput('');
      await loadReports();
      await refreshData();
    } catch (err: any) {
      showToast(`Gagal memproses pembayaran: ${err.message}`, 'error');
    }
  };

  // Add new payable
  const handleCreatePayable = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseInt(newAmountInput.replace(/\D/g, ''), 10) || 0;
    if (!newSupplier.trim() || amount <= 0) {
      showToast('Harap isi supplier dan nominal dengan benar', 'error');
      return;
    }

    try {
      await debtRepository.createPayable({
        supplierName: newSupplier.trim(),
        invoiceDate: new Date().toISOString().slice(0, 10),
        dueDate: newDueDate,
        totalAmount: amount,
        category: 'Bahan Baku',
        notes: newNotes.trim() || undefined
      });

      showToast('Faktur utang supplier berhasil dicatat!', 'success');
      setIsAddPayableOpen(false);
      setNewSupplier('');
      setNewAmountInput('');
      setNewNotes('');
      await loadReports();
    } catch (err: any) {
      showToast(`Gagal: ${err.message}`, 'error');
    }
  };

  // Add new receivable
  const handleCreateReceivable = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseInt(newAmountInput.replace(/\D/g, ''), 10) || 0;
    if (!newCustomer.trim() || amount <= 0) {
      showToast('Harap isi pelanggan dan nominal dengan benar', 'error');
      return;
    }

    try {
      await debtRepository.createReceivable({
        customerName: newCustomer.trim(),
        invoiceNumber: `INV/CT-${Date.now().toString().slice(-4)}`,
        orderDate: new Date().toISOString().slice(0, 10),
        dueDate: newDueDate,
        totalAmount: amount,
        channel: 'Catering',
        notes: newNotes.trim() || undefined
      });

      showToast('Tagihan piutang catering berhasil dicatat!', 'success');
      setIsAddReceivableOpen(false);
      setNewCustomer('');
      setNewAmountInput('');
      setNewNotes('');
      await loadReports();
    } catch (err: any) {
      showToast(`Gagal: ${err.message}`, 'error');
    }
  };

  // Print P&L to PDF
  const handlePrintPnl = () => {
    if (!pnlReport) return;

    const expenseRowsHtml = Object.entries(pnlReport.operatingExpenses)
      .filter(([_, val]) => val > 0)
      .map(
        ([cat, val]) =>
          `<tr><td style="padding-left: 20px;">${cat}</td><td class="text-right">${formatRupiah(val)}</td></tr>`
      )
      .join('');

    const htmlContent = `
      <div style="margin-bottom: 20px;">
        <strong>Periode Laporan:</strong> ${pnlReport.periodLabel} (${pnlReport.startDate} s/d ${pnlReport.endDate})
      </div>
      <table>
        <thead>
          <tr>
            <th>Pos Akun Keuangan</th>
            <th class="text-right">Nominal (Rupiah)</th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-highlight">
            <td><strong>1. PENDAPATAN USAHA</strong></td>
            <td></td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Penjualan Kotor</td>
            <td class="text-right">${formatRupiah(pnlReport.grossSales)}</td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Potongan Diskon Penjualan</td>
            <td class="text-right">(${formatRupiah(pnlReport.discounts)})</td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Refund & Retur</td>
            <td class="text-right">(${formatRupiah(pnlReport.refunds)})</td>
          </tr>
          <tr class="text-bold">
            <td>TOTAL PENJUALAN BERSIH</td>
            <td class="text-right">${formatRupiah(pnlReport.netSales)}</td>
          </tr>

          <tr class="bg-highlight">
            <td><strong>2. HARGA POKOK PENJUALAN (HPP)</strong></td>
            <td></td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Persediaan Awal Bahan</td>
            <td class="text-right">${formatRupiah(pnlReport.beginningInventory)}</td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Pembelian Bahan untuk Persediaan</td>
            <td class="text-right">${formatRupiah(pnlReport.purchasesForInventory)}</td>
          </tr>
          <tr>
            <td style="padding-left: 20px;">Persediaan Akhir Bahan</td>
            <td class="text-right">(${formatRupiah(pnlReport.endingInventory)})</td>
          </tr>
          <tr class="text-bold">
            <td>TOTAL HPP (BAHAN TERPAKAI & KERUSAKAN)</td>
            <td class="text-right">${formatRupiah(pnlReport.costOfGoodsSold)}</td>
          </tr>

          <tr class="bg-highlight" style="font-size: 14px;">
            <td><strong>LABA KOTOR (GROSS PROFIT)</strong></td>
            <td class="text-right" style="color: #800020;"><strong>${formatRupiah(pnlReport.grossProfit)}</strong> (Margin: ${pnlReport.grossMarginPct}%)</td>
          </tr>

          <tr class="bg-highlight">
            <td><strong>3. BEBAN OPERASIONAL USAHA</strong></td>
            <td></td>
          </tr>
          ${expenseRowsHtml || '<tr><td style="padding-left: 20px;">Tidak ada beban operasional</td><td class="text-right">Rp0</td></tr>'}
          <tr class="text-bold">
            <td>TOTAL BEBAN OPERASIONAL</td>
            <td class="text-right">(${formatRupiah(pnlReport.totalOperatingExpenses)})</td>
          </tr>

          <tr class="bg-highlight" style="font-size: 15px; border-top: 2px solid #800020; border-bottom: 2px solid #800020;">
            <td><strong>LABA BERSIH USAHA (NET PROFIT)</strong></td>
            <td class="text-right" style="color: ${pnlReport.netProfit >= 0 ? '#15803d' : '#b91c1c'}; font-size: 16px;">
              <strong>${formatRupiah(pnlReport.netProfit)}</strong> (Margin: ${pnlReport.netMarginPct}%)
            </td>
          </tr>
        </tbody>
      </table>
    `;

    printFinancialReport(`Laporan Laba Rugi - ${pnlReport.periodLabel}`, htmlContent);
  };

  // Export P&L to CSV
  const handleExportPnlCsv = () => {
    if (!pnlReport) return;
    const headers = ['Pos Akun', 'Nominal (Rp)', 'Keterangan'];
    const rows: (string | number)[][] = [
      ['Penjualan Kotor', pnlReport.grossSales, 'Omzet bruto'],
      ['Diskon Penjualan', pnlReport.discounts, 'Pengurang omzet'],
      ['Refund & Retur', pnlReport.refunds, 'Pengurang omzet'],
      ['Penjualan Bersih', pnlReport.netSales, 'Pendapatan bersih'],
      ['HPP (Bahan Terpakai)', pnlReport.costOfGoodsSold, 'Harga Pokok Penjualan'],
      ['Laba Kotor', pnlReport.grossProfit, `Margin: ${pnlReport.grossMarginPct}%`],
      ['Total Beban Operasional', pnlReport.totalOperatingExpenses, 'Biaya operasional warung & catering'],
      ['Laba Bersih', pnlReport.netProfit, `Margin Bersih: ${pnlReport.netMarginPct}%`]
    ];

    Object.entries(pnlReport.operatingExpenses).forEach(([cat, val]) => {
      if (val > 0) rows.push([`Beban: ${cat}`, val, 'Rincian Operasional']);
    });

    const csvContent = generateCsv(headers, rows);
    downloadFile(
      csvContent,
      `Laba_Rugi_Warung_Medan_${dateRange.startDate}_${dateRange.endDate}.csv`,
      'text/csv;charset=utf-8;'
    );
    showToast('Laporan Laba Rugi berhasil diekspor ke CSV!', 'success');
  };

  return (
    <div className="space-y-4 pb-20 max-w-4xl mx-auto">
      {/* 1. Period Filter */}
      <PeriodFilter />

      {/* 2. Sub Tabs for Reports */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-xl overflow-x-auto">
        <button
          onClick={() => setActiveReportTab('PNL')}
          className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-lg transition-all min-h-[36px] whitespace-nowrap ${
            activeReportTab === 'PNL'
              ? 'bg-white text-[#800020] shadow-sm font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Laba Rugi (P&L)
        </button>
        <button
          onClick={() => setActiveReportTab('CASHFLOW')}
          className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-lg transition-all min-h-[36px] whitespace-nowrap ${
            activeReportTab === 'CASHFLOW'
              ? 'bg-white text-[#800020] shadow-sm font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Arus Kas (Cash Flow)
        </button>
        <button
          onClick={() => setActiveReportTab('DEBTS')}
          className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-lg transition-all min-h-[36px] whitespace-nowrap ${
            activeReportTab === 'DEBTS'
              ? 'bg-white text-[#800020] shadow-sm font-bold'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Utang & Piutang
        </button>
      </div>

      {/* Action Bar (Print / Export) */}
      <div className="flex items-center justify-end gap-2">
        <button
          onClick={handlePrintPnl}
          className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 shadow-xs"
        >
          <Printer className="w-3.5 h-3.5 text-[#800020]" />
          <span>Cetak PDF / Bon</span>
        </button>
        <button
          onClick={handleExportPnlCsv}
          className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 shadow-xs"
        >
          <Download className="w-3.5 h-3.5 text-emerald-700" />
          <span>Ekspor CSV</span>
        </button>
      </div>

      {/* REPORT CONTENT */}
      {isLoading ? (
        <div className="py-16 text-center text-xs text-slate-400">Menghitung laporan keuangan...</div>
      ) : activeReportTab === 'PNL' && pnlReport ? (
        /* ================= LABA RUGI REPORT ================= */
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 leading-tight">
              Laporan Laba Rugi (Income Statement)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Standar SAK EMKM · Periode {pnlReport.periodLabel}
            </p>
          </div>

          {/* Section 1: Penjualan Bersih */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              1. Penjualan & Pendapatan Usaha
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Penjualan Kotor (Gross Sales)</span>
                <span className="font-mono tabular-nums font-semibold">{formatRupiah(pnlReport.grossSales)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Diskon Penjualan</span>
                <span className="font-mono tabular-nums text-rose-600">-{formatRupiah(pnlReport.discounts)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Refund & Retur</span>
                <span className="font-mono tabular-nums text-rose-600">-{formatRupiah(pnlReport.refunds)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-900">
                <span>Penjualan Bersih (Net Sales)</span>
                <span className="font-mono tabular-nums text-emerald-700">{formatRupiah(pnlReport.netSales)}</span>
              </div>
            </div>
          </div>

          {/* Section 2: HPP */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              2. Harga Pokok Penjualan (HPP Bahan Baku)
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Persediaan Awal Bahan Baku</span>
                <span className="font-mono tabular-nums">{formatRupiah(pnlReport.beginningInventory)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pembelian Bahan Bersih</span>
                <span className="font-mono tabular-nums">+{formatRupiah(pnlReport.purchasesForInventory)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Persediaan Akhir Bahan Baku</span>
                <span className="font-mono tabular-nums">-{formatRupiah(pnlReport.endingInventory)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-900">
                <span>Total HPP (Bahan Terpakai di Dapur)</span>
                <span className="font-mono tabular-nums text-amber-800">{formatRupiah(pnlReport.costOfGoodsSold)}</span>
              </div>
            </div>
          </div>

          {/* Gross Profit Banner */}
          <div className="p-3.5 bg-[#800020]/10 rounded-2xl border border-[#800020]/20 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-[#800020] uppercase">Laba Kotor Usaha</span>
              <div className="text-[11px] text-slate-600 mt-0.5">Gross Margin: {pnlReport.grossMarginPct}%</div>
            </div>
            <div className="text-lg font-extrabold font-mono tabular-nums text-[#800020]">
              {formatRupiah(pnlReport.grossProfit)}
            </div>
          </div>

          {/* Section 3: Beban Operasional */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              3. Beban Operasional Usaha
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
              {Object.entries(pnlReport.operatingExpenses)
                .filter(([_, val]) => val > 0)
                .map(([cat, val]) => (
                  <div key={cat} className="flex justify-between text-slate-600">
                    <span>{cat}</span>
                    <span className="font-mono tabular-nums">{formatRupiah(val)}</span>
                  </div>
                ))}
              {pnlReport.totalOperatingExpenses === 0 && (
                <div className="text-slate-400 italic">Belum ada beban operasional tercatat pada periode ini.</div>
              )}
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-900">
                <span>Total Beban Operasional</span>
                <span className="font-mono tabular-nums text-rose-700">{formatRupiah(pnlReport.totalOperatingExpenses)}</span>
              </div>
            </div>
          </div>

          {/* Net Profit Banner */}
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between ${
              pnlReport.netProfit >= 0
                ? 'bg-emerald-50 border-emerald-200'
                : 'bg-rose-50 border-rose-200'
            }`}
          >
            <div>
              <span
                className={`text-xs font-bold uppercase ${
                  pnlReport.netProfit >= 0 ? 'text-emerald-900' : 'text-rose-900'
                }`}
              >
                Laba Bersih Usaha (Net Profit)
              </span>
              <div className="text-[11px] text-slate-600 mt-0.5">
                Net Profit Margin: {pnlReport.netMarginPct}%
              </div>
            </div>
            <div
              className={`text-xl font-extrabold font-mono tabular-nums ${
                pnlReport.netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'
              }`}
            >
              {formatRupiah(pnlReport.netProfit)}
            </div>
          </div>
        </div>
      ) : activeReportTab === 'CASHFLOW' && cashFlowReport ? (
        /* ================= CASH FLOW REPORT ================= */
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 leading-tight">
              Laporan Arus Kas (Cash Flow Statement)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Arus Kas Masuk & Keluar Riil Akun Kas / Bank / QRIS
            </p>
          </div>

          {/* Inflows */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
              Arus Kas Masuk (Inflow)
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Penerimaan Kas dari Penjualan Bersih</span>
                <span className="font-mono tabular-nums text-emerald-700">+{formatRupiah(cashFlowReport.cashInflowFromSales)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pelunasan Piutang Pelanggan Catering</span>
                <span className="font-mono tabular-nums text-emerald-700">+{formatRupiah(cashFlowReport.cashInflowFromReceivables)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Setoran Modal Tambahan Pemilik</span>
                <span className="font-mono tabular-nums text-emerald-700">+{formatRupiah(cashFlowReport.cashInflowFromCapital)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-900">
                <span>Total Arus Kas Masuk</span>
                <span className="font-mono tabular-nums text-emerald-700">+{formatRupiah(cashFlowReport.totalCashInflow)}</span>
              </div>
            </div>
          </div>

          {/* Outflows */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-rose-800 uppercase tracking-wide">
              Arus Kas Keluar (Outflow)
            </div>
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Pembayaran Beban Operasional Usaha</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.cashOutflowOperating)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pembelian Bahan Baku Tunai</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.cashOutflowInventoryPurchases)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pelunasan Utang Supplier Bahan</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.cashOutflowDebtPayments)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pembelian Aset Usaha</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.cashOutflowAssetPurchases)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Pengambilan Pribadi (Prive Pemilik)</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.cashOutflowPrive)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold text-slate-900">
                <span>Total Arus Kas Keluar</span>
                <span className="font-mono tabular-nums text-rose-700">-{formatRupiah(cashFlowReport.totalCashOutflow)}</span>
              </div>
            </div>
          </div>

          {/* Net Cash Flow & Ending Cash */}
          <div className="p-4 bg-slate-100 rounded-2xl border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between text-slate-700 font-semibold">
              <span>Arus Kas Bersih Periode Ini</span>
              <span className={`font-mono font-bold ${cashFlowReport.netCashFlow >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {cashFlowReport.netCashFlow >= 0 ? '+' : ''}{formatRupiah(cashFlowReport.netCashFlow)}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-extrabold text-slate-900">
              <span>Total Saldo Kas & Bank Akhir</span>
              <span className="font-mono text-[#800020]">{formatRupiah(cashFlowReport.endingCash)}</span>
            </div>
          </div>
        </div>
      ) : (
        /* ================= UTANG & PIUTANG ================= */
        <div className="space-y-4">
          {/* Payables (Utang Supplier) */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Utang ke Supplier Bahan Baku</h3>
                <p className="text-[11px] text-slate-500">Kewajiban pembayaran tempo untuk ayam, ikan, beras</p>
              </div>
              <button
                onClick={() => setIsAddPayableOpen(true)}
                className="px-2.5 py-1.5 rounded-lg bg-[#800020] text-white text-xs font-bold hover:bg-[#660019]"
              >
                + Tambah Utang
              </button>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {payables.length === 0 ? (
                <div className="py-6 text-center text-slate-400">Tidak ada utang supplier aktif.</div>
              ) : (
                payables.map((p) => (
                  <div key={p.id} className="py-3 flex items-start justify-between gap-3">
                    <div>
                      <div className="font-bold text-slate-900">{p.supplierName}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Jatuh Tempo: {formatIndonesianDate(p.dueDate, true)} {p.notes ? `· ${p.notes}` : ''}
                      </div>
                      <div className="mt-1 flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            p.status === 'LUNAS'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-800'
                          }`}
                        >
                          {p.status}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Sudah Dibayar: {formatRupiah(p.paidAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold text-sm text-slate-900">
                        {formatRupiah(p.remainingAmount)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Total Faktur: {formatRupiah(p.totalAmount)}
                      </div>
                      {p.status !== 'LUNAS' && (
                        <button
                          onClick={() => {
                            setSettlementTarget({ type: 'PAYABLE', item: p });
                            setSettleAmountInput(formatRupiah(p.remainingAmount));
                          }}
                          className="mt-1.5 text-xs font-bold text-[#800020] hover:underline block ml-auto"
                        >
                          Bayar Cicilan
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Receivables (Piutang Catering) */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Piutang Pelanggan Catering</h3>
                <p className="text-[11px] text-slate-500">Tagihan belum lunas untuk pesanan pesta, arisan, kantor</p>
              </div>
              <button
                onClick={() => setIsAddReceivableOpen(true)}
                className="px-2.5 py-1.5 rounded-lg bg-[#800020] text-white text-xs font-bold hover:bg-[#660019]"
              >
                + Tambah Piutang
              </button>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {receivables.length === 0 ? (
                <div className="py-6 text-center text-slate-400">Tidak ada piutang catering aktif.</div>
              ) : (
                receivables.map((r) => (
                  <div key={r.id} className="py-3 flex items-start justify-between gap-3">
                    <div>
                      <div className="font-bold text-slate-900">{r.customerName}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        No. Invoice: {r.invoiceNumber} · Tempo: {formatIndonesianDate(r.dueDate)}
                      </div>
                      <div className="mt-1 flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            r.status === 'LUNAS'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-indigo-50 text-indigo-700'
                          }`}
                        >
                          {r.status}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          DP / Diterima: {formatRupiah(r.paidAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold text-sm text-emerald-700">
                        {formatRupiah(r.remainingAmount)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Total Tagihan: {formatRupiah(r.totalAmount)}
                      </div>
                      {r.status !== 'LUNAS' && (
                        <button
                          onClick={() => {
                            setSettlementTarget({ type: 'RECEIVABLE', item: r });
                            setSettleAmountInput(formatRupiah(r.remainingAmount));
                          }}
                          className="mt-1.5 text-xs font-bold text-emerald-700 hover:underline block ml-auto"
                        >
                          Catat Pelunasan
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Settlement Modal */}
      {settlementTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {settlementTarget.type === 'PAYABLE' ? 'Bayar Utang Supplier' : 'Terima Pelunasan Piutang'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Nama:{' '}
              <strong className="text-slate-800">
                {settlementTarget.type === 'PAYABLE'
                  ? (settlementTarget.item as Payable).supplierName
                  : (settlementTarget.item as Receivable).customerName}
              </strong>
            </p>

            <form onSubmit={handleSettleDebt} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nominal Pembayaran (Rp)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  placeholder="0"
                  value={settleAmountInput}
                  onChange={(e) => setSettleAmountInput(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm font-bold font-mono tabular-nums focus:ring-2 focus:ring-[#800020]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {settlementTarget.type === 'PAYABLE' ? 'Akun Sumber Pembayaran' : 'Masuk ke Akun'}
                </label>
                <select
                  value={settleAccountId}
                  onChange={(e) => setSettleAccountId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} ({formatRupiah(acc.currentBalance)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSettlementTarget(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 min-h-[44px]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#800020] text-xs font-bold text-white hover:bg-[#660019] min-h-[44px]"
                >
                  Konfirmasi Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Payable Modal */}
      {isAddPayableOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-3">Catat Utang Supplier Baru</h3>
            <form onSubmit={handleCreatePayable} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Supplier</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Toko Beras Jaya"
                  value={newSupplier}
                  onChange={(e) => setNewSupplier(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nominal Tagihan (Rp)</label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  placeholder="0"
                  value={newAmountInput}
                  onChange={(e) => setNewAmountInput(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal Jatuh Tempo</label>
                <input
                  type="date"
                  required
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Keterangan</label>
                <input
                  type="text"
                  placeholder="Ket pasokan bahan"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddPayableOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#800020] text-white text-xs font-bold"
                >
                  Simpan Utang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Receivable Modal */}
      {isAddReceivableOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-3">Catat Piutang Catering Baru</h3>
            <form onSubmit={handleCreateReceivable} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Pelanggan / Acara</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Bpk. Siregar (Catering Pernikahan)"
                  value={newCustomer}
                  onChange={(e) => setNewCustomer(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Total Tagihan (Rp)</label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  placeholder="0"
                  value={newAmountInput}
                  onChange={(e) => setNewAmountInput(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal Jatuh Tempo</label>
                <input
                  type="date"
                  required
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Keterangan</label>
                <input
                  type="text"
                  placeholder="Paket 150 porsi"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 text-xs"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddReceivableOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#800020] text-white text-xs font-bold"
                >
                  Simpan Piutang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
